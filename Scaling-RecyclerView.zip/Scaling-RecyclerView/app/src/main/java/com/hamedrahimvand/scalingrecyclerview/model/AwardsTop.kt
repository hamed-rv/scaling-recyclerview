package com.farzaninstitute.farzanlibrary.awards.model

import android.view.View

class AwardsTop private constructor(
    val name: String?,
    val iconUrl: String?,
    val score: Int?,
    val visibility: Int
) {
    companion object {
        val TYPE_GRID = 0
        val TYPE_LINEAR = 1
    }

    data class Builder(
        var name: String? = null,
        var iconUrl: String? = null,
        var score: Int? = null,
        var visibility: Int = View.VISIBLE
    ) {
        fun name(name: String?) = apply { this.name = name }
        fun iconUrl(iconUrl: String?) = apply { this.iconUrl = iconUrl }
        fun score(score: Int?) = apply { this.score = score }
        fun visibility(visibility: Int) = apply { this.visibility = visibility }
        fun build() = AwardsTop(name, iconUrl, score,visibility)
    }


}