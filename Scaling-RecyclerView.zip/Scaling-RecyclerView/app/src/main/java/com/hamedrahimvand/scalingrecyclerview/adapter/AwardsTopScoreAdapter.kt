package com.hamedrahimvand.scalingrecyclerview.adapter

import android.content.Context
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout

class AwardsTopScoreAdapter(val context: Context, val dataList: ArrayList<AwardsTop>) :
    RecyclerView.Adapter<AwardsTopScoreAdapter.AwardsTopScoreViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AwardsTopScoreViewHolder {
        val view =
            LayoutInflater.from(context).inflate(R.layout.item_awards_top_score, parent, false)
        return AwardsTopScoreViewHolder(view)
    }

    lateinit var recyclerView: RecyclerView
    override fun getItemCount(): Int {
        return dataList.size
    }

    var firstTime = true
    override fun onBindViewHolder(holder: AwardsTopScoreViewHolder, position: Int) {
        val itemData = dataList[holder.adapterPosition]
        holder.colAwardsTopParent.visibility = itemData.visibility
        loadGlide(
            itemData.iconUrl!!,
            holder.ico,
            ContextCompat.getDrawable(context, R.drawable.medal_gray)!!,
            56,
            56
        )
        holder.txvName.text = itemData.name
        holder.txvScore.text = context.getString(R.string.score, itemData.score.toString())

        if (position == 0 || position == dataList.size-1){
            holder.colAwardsTopParent.layoutParams.width = ConverterUtlis.dpToPx(60f).toInt()
        }else{
            holder.colAwardsTopParent.layoutParams.width = ViewGroup.LayoutParams.WRAP_CONTENT
        }
        if (firstTime) {
            if (position == 1) {
                holder.frlSecondLayout.scaleX = 1.2f
                holder.frlSecondLayout.scaleY = 1.2f
                holder.frlThirdLayout.scaleX = 1.45f
                holder.frlThirdLayout.scaleY = 1.45f
            }
            if (position == 2) {
                firstTime = false
                holder.itemView.scaleX = 0.8f
                holder.itemView.scaleY = 0.8f
                holder.frlSecondLayout.scaleX = 1.0f
                holder.frlSecondLayout.scaleY = 1.0f
                holder.frlThirdLayout.scaleX = 1.0f
                holder.frlThirdLayout.scaleY = 1.0f
            }
        }
    }

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)
        this.recyclerView = recyclerView
    }

    private fun loadGlide(
        photoUrl: String,
        imv: AppCompatImageView,
        placeHolder: Drawable,
        width: Int,
        height: Int
    ) {
        Glide.with(imv.context).load(photoUrl)
            .asBitmap()
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .placeholder(placeHolder)
            .override(width, height)
            .into(object : BitmapImageViewTarget(imv) {
                override fun setResource(resource: Bitmap?) {
                    val circularBitmapDrawable =
                        RoundedBitmapDrawableFactory.create(context.resources, resource)
                    circularBitmapDrawable.isCircular = true
                    imv.setImageDrawable(circularBitmapDrawable)
                }
            })
    }

    class AwardsTopScoreViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val colAwardsTopParent = itemView.findViewById<ConstraintLayout>(R.id.col_awards_top_parent)
        val ico = itemView.findViewById<AppCompatImageView>(R.id.imv_awards_top_ico)
        val txvName = itemView.findViewById<AppCompatTextView>(R.id.txv_awards_top_name)
        val txvScore = itemView.findViewById<AppCompatTextView>(R.id.txv_awards_top_score)
        val frlSecondLayout = itemView.findViewById<FrameLayout>(R.id.frl_secondLayout)
        val frlThirdLayout = itemView.findViewById<FrameLayout>(R.id.frl_thirdLayout)
    }

}