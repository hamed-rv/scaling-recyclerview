package com.farzaninstitute.farzanlibrary.awards

import android.animation.Animator
import android.content.Context
import android.util.AttributeSet
import android.view.animation.AnimationUtils
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearSnapHelper
import androidx.recyclerview.widget.RecyclerView
import com.farzaninstitute.farzanlibrary.R
import com.farzaninstitute.farzanlibrary.awards.adapter.AwardsTopScoreAdapter
import com.farzaninstitute.farzanlibrary.awards.model.AwardsTop
import kotlinx.android.synthetic.main.awards.view.*
import android.view.ViewTreeObserver




class AwardsView(context: Context, attributeSet: AttributeSet?, defStyle: Int) :
    ConstraintLayout(context, attributeSet, defStyle) {
    constructor(context: Context, attributeSet: AttributeSet?) : this(context, attributeSet, 0)
    constructor(context: Context) : this(context, null, 0)

    var listType = Awards.TYPE_GRID
    lateinit var awardsTopScoreAdapter: AwardsTopScoreAdapter
    lateinit var awardsTopScoreList: ArrayList<AwardsTop>
    lateinit var awardsAdapter: AwardsAdapter
    lateinit var awardsList: ArrayList<Awards>
    lateinit var awardsLayoutManager: GridLayoutManager

    init {
        inflate(context, R.layout.awards, this)
        initRecyclerView()
    }

    private fun initRecyclerView() {
        rcv_awardsTop.setHasFixedSize(true)
        rcv_awards.setHasFixedSize(true)
        val topSnapHelper = LinearSnapHelper()
        topSnapHelper.attachToRecyclerView(rcv_awardsTop)
        setLayoutManager()
        setGridInAnimation()
        setListener()
        autoSpan()
    }

    fun autoSpan(){
        rcv_awards.viewTreeObserver.addOnGlobalLayoutListener(
            object : ViewTreeObserver.OnGlobalLayoutListener {
                override fun onGlobalLayout() {
                    rcv_awards.viewTreeObserver.removeOnGlobalLayoutListener(this)
                    val viewWidth = rcv_awards.measuredWidth
                    val cardViewWidth =
                        context.resources.getDimension(R.dimen.award_grid_icon_width)
                    val newSpanCount = Math.floor((viewWidth / cardViewWidth).toDouble()).toInt()
                    (rcv_awards.layoutManager as GridLayoutManager).spanCount = newSpanCount
                    rcv_awards.requestLayout()
                }
            })
    }
    fun setLayoutManager() {
        rcv_awardsTop.layoutManager = AwardsLayoutManager(context, RecyclerView.HORIZONTAL, false)

        awardsLayoutManager = GridLayoutManager(context, 4, RecyclerView.VERTICAL, false)
        rcv_awards.layoutManager = awardsLayoutManager
    }

    fun setGridInAnimation() {
        val resId = R.anim.grid_layout_left_to_right
        val animation = AnimationUtils.loadLayoutAnimation(context, resId)
        rcv_awards.layoutAnimation = animation
    }

    fun generateTopScoreAdapters(topScores: ArrayList<AwardsTop>) {
        rcv_awardsTop.setHasFixedSize(true)
        awardsTopScoreList = topScores
        awardsTopScoreAdapter = AwardsTopScoreAdapter(context, topScores)
        rcv_awardsTop.adapter = awardsTopScoreAdapter

    }

    private fun setListener() {

        imb_awards_listType.setOnClickListener {
            changeListType()
        }
    }

    fun generateAwardsAdapters(awards: ArrayList<Awards>) {
        rcv_awards.setHasFixedSize(true)
        awardsList = awards
        awardsAdapter =
                AwardsAdapter(context, awards, object : AwardsInterface.onItemClickListener {
                    override fun onClick() {
                        changeListType()
                    }
                })
        rcv_awards.adapter = awardsAdapter

    }

    fun changeListType() {
        if (listType == Awards.TYPE_GRID) {
            listType = Awards.TYPE_LINEAR

            imb_awards_listType.animate().rotation(180f)
                .setListener(object : Animator.AnimatorListener {
                    override fun onAnimationRepeat(animation: Animator?) {}
                    override fun onAnimationCancel(animation: Animator?) {}
                    override fun onAnimationStart(animation: Animator?) {}
                    override fun onAnimationEnd(animation: Animator?) {
                        imb_awards_listType.setImageDrawable(
                            ContextCompat.getDrawable(
                                context,
                                R.drawable.ic_grid
                            )
                        )
                    }
                }).duration = 300
            awardsAdapter.convertListType(Awards.TYPE_LINEAR)
            awardsAdapter.notifyItemRangeChanged(0, awardsList.size)
            awardsLayoutManager.spanCount = 1
        } else {
            listType = Awards.TYPE_GRID
            awardsAdapter.convertListType(Awards.TYPE_GRID)
            imb_awards_listType.animate().rotation(0f)
                .setListener(object : Animator.AnimatorListener {
                    override fun onAnimationRepeat(animation: Animator?) {}
                    override fun onAnimationCancel(animation: Animator?) {}
                    override fun onAnimationStart(animation: Animator?) {}
                    override fun onAnimationEnd(animation: Animator?) {

                        imb_awards_listType.setImageDrawable(
                            ContextCompat.getDrawable(
                                context,
                                R.drawable.ic_list
                            )
                        )
                    }
                }).duration = 300
            awardsAdapter.notifyItemRangeChanged(0, awardsList.size)
            awardsLayoutManager.spanCount = 4
        }
    }

    fun addItemToTop(item: AwardsTop) {
        awardsTopScoreList.add(item)
        awardsTopScoreAdapter.notifyItemInserted(awardsTopScoreList.size)
    }

    fun addItemToTop(items: ArrayList<AwardsTop>) {
        awardsTopScoreList.addAll(items)
        awardsTopScoreAdapter.notifyItemInserted(awardsTopScoreList.size)
    }

    fun addItemToAwards(item: Awards) {
        awardsList.add(item)
        awardsAdapter.notifyItemInserted(awardsTopScoreList.size)
    }

    fun addItemToAwards(items: ArrayList<Awards>) {
        awardsList.addAll(items)
        awardsAdapter.notifyItemInserted(awardsTopScoreList.size)
    }

}