package com.farzaninstitute.farzanlibrary.awards

interface AwardsInterface {
    interface onItemClickListener{
        fun onClick()
    }
}